 
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Laravel CRUD Barang</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-success" href="<?php echo e(route('barangs.create')); ?>"> Create New Barang</a>
            </div>
        </div>
    </div>
   
    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>
   
    <table class="table table-bordered">
        <tr>
            <th>No</th>
            <th>Name</th>
            <th>Harga</th>
            <th>Kategori</th>
            <th>Stok</th>
            <th width="280px">Action</th>
        </tr>
        <?php $__currentLoopData = $barangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e(++$i); ?></td>
            <td><?php echo e($barang->name); ?></td>
            <td><?php echo e($barang->harga); ?></td>
            <td><?php echo e($barang->kategori); ?></td>
            <td><?php echo e($barang->stok); ?></td>
            <td>
                <form action="<?php echo e(route('barangs.destroy',$barang->id)); ?>" method="POST">
   
                    <a class="btn btn-info" href="<?php echo e(route('barangs.show',$barang->id)); ?>">Show</a>
    
                    <a class="btn btn-primary" href="<?php echo e(route('barangs.edit',$barang->id)); ?>">Edit</a>
   
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
      
                    <button type="submit" class="btn btn-danger">Delete</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
  
    <?php echo $barangs->links(); ?>

      
<?php $__env->stopSection(); ?>
<?php echo $__env->make('barangs.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\crud laravel barang\resources\views/barangs/index.blade.php ENDPATH**/ ?>